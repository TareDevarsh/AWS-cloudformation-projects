#!/usr/bin/env bash
# =============================================================================
# Master Deploy Script — Ad Creative Performance Scorer
# Usage: ./deploy.sh [dev|staging|prod] [aws-region] [alert-email]
# Example: ./deploy.sh dev us-east-1 alerts@yourcompany.com
# =============================================================================

set -euo pipefail

# ── Configuration ─────────────────────────────────────────────────────────────
ENVIRONMENT="${1:-dev}"
REGION="${2:-us-east-1}"
ALERT_EMAIL="${3:-alerts@example.com}"
PROJECT_NAME="ad-scorer"
TEMPLATES_DIR="./templates"

echo "=== Ad Creative Scorer — Deploying to: ${ENVIRONMENT} / ${REGION} ==="

# ── Helper: deploy a stack and wait for completion ────────────────────────────
deploy_stack() {
  local stack_name="$1"
  local template="$2"
  shift 2
  local params=("$@")

  echo ""
  echo ">>> Deploying stack: ${stack_name}"

  aws cloudformation deploy \
    --stack-name "${stack_name}" \
    --template-file "${template}" \
    --parameter-overrides \
        "ProjectName=${PROJECT_NAME}" \
        "Environment=${ENVIRONMENT}" \
        "${params[@]}" \
    --capabilities CAPABILITY_NAMED_IAM \
    --region "${REGION}" \
    --no-fail-on-empty-changeset

  echo "✓ ${stack_name} deployed successfully"
}

# ── STEP 1: Foundation (S3, KMS, IAM Roles) ───────────────────────────────────
deploy_stack \
  "${PROJECT_NAME}-${ENVIRONMENT}-foundation" \
  "${TEMPLATES_DIR}/01-foundation.yaml"

# ── STEP 2: Compute & Storage (DynamoDB, Lambda Functions) ───────────────────
deploy_stack \
  "${PROJECT_NAME}-${ENVIRONMENT}-compute" \
  "${TEMPLATES_DIR}/02-compute-and-storage.yaml"

# ── STEP 3: API Gateway ───────────────────────────────────────────────────────
deploy_stack \
  "${PROJECT_NAME}-${ENVIRONMENT}-api" \
  "${TEMPLATES_DIR}/03-api-gateway.yaml" \
  "EnableAPIKey=true"

# ── STEP 4: Step Functions Orchestration ─────────────────────────────────────
deploy_stack \
  "${PROJECT_NAME}-${ENVIRONMENT}-orchestration" \
  "${TEMPLATES_DIR}/04-step-functions.yaml"

# ── STEP 5: SageMaker ML Platform ─────────────────────────────────────────────
echo ""
echo ">>> NOTE: Template 05 starts a SageMaker Training Job immediately."
echo "    Ensure training data CSVs are uploaded to S3 before deploying."
echo "    S3 path: s3://${PROJECT_NAME}-ml-artifacts-<account>-${ENVIRONMENT}/training-data/"
echo ""
read -p "    Training data ready? Deploy SageMaker stack? (y/N) " DEPLOY_ML
if [[ "${DEPLOY_ML}" =~ ^[Yy]$ ]]; then
  deploy_stack \
    "${PROJECT_NAME}-${ENVIRONMENT}-ml" \
    "${TEMPLATES_DIR}/05-sagemaker.yaml" \
    "TrainingInstanceType=ml.m5.xlarge" \
    "InferenceInstanceType=ml.t3.medium"
else
  echo "    Skipping SageMaker stack. Deploy manually when ready:"
  echo "    aws cloudformation deploy --stack-name ${PROJECT_NAME}-${ENVIRONMENT}-ml \\"
  echo "      --template-file ${TEMPLATES_DIR}/05-sagemaker.yaml \\"
  echo "      --parameter-overrides ProjectName=${PROJECT_NAME} Environment=${ENVIRONMENT} \\"
  echo "      --capabilities CAPABILITY_NAMED_IAM --region ${REGION}"
fi

# ── STEP 6: Monitoring & Alarms ───────────────────────────────────────────────
deploy_stack \
  "${PROJECT_NAME}-${ENVIRONMENT}-monitoring" \
  "${TEMPLATES_DIR}/06-monitoring.yaml" \
  "AlertEmail=${ALERT_EMAIL}"

# ── Output summary ─────────────────────────────────────────────────────────────
echo ""
echo "=== Deployment Complete ==="
echo ""
echo "Fetching stack outputs..."

API_ENDPOINT=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT_NAME}-${ENVIRONMENT}-api" \
  --region "${REGION}" \
  --query "Stacks[0].Outputs[?OutputKey=='APIEndpoint'].OutputValue" \
  --output text 2>/dev/null || echo "N/A")

DASHBOARD_URL="https://${REGION}.console.aws.amazon.com/cloudwatch/home?region=${REGION}#dashboards:name=${PROJECT_NAME}-${ENVIRONMENT}"

echo "  API Endpoint:      ${API_ENDPOINT}"
echo "  Upload URL:        ${API_ENDPOINT}/v1/upload"
echo "  Score URL:         ${API_ENDPOINT}/v1/score"
echo "  Dashboard:         ${DASHBOARD_URL}"
echo ""
echo "Next steps:"
echo "  1. Confirm SNS email subscription (check ${ALERT_EMAIL})"
echo "  2. Upload training data to S3 (see README.md)"
echo "  3. After training completes, update ModelS3Key in Template 05"
echo "  4. Test the API: curl -X POST ${API_ENDPOINT}/v1/upload -H 'Content-Type: application/json' -d '{\"content_type\":\"image/jpeg\",\"campaign_id\":\"test-campaign\"}'"
