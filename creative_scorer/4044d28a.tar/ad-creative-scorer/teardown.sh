#!/usr/bin/env bash
# Tear down all stacks in REVERSE dependency order.
# WARNING: S3 buckets have DeletionPolicy: Retain — empty them manually first.

set -euo pipefail

ENVIRONMENT="${1:-dev}"
REGION="${2:-us-east-1}"
PROJECT_NAME="ad-scorer"

STACKS=(
  "${PROJECT_NAME}-${ENVIRONMENT}-monitoring"
  "${PROJECT_NAME}-${ENVIRONMENT}-ml"
  "${PROJECT_NAME}-${ENVIRONMENT}-orchestration"
  "${PROJECT_NAME}-${ENVIRONMENT}-api"
  "${PROJECT_NAME}-${ENVIRONMENT}-compute"
  "${PROJECT_NAME}-${ENVIRONMENT}-foundation"
)

for stack in "${STACKS[@]}"; do
  echo "Deleting stack: ${stack}"
  aws cloudformation delete-stack \
    --stack-name "${stack}" \
    --region "${REGION}" || echo "  Stack not found or already deleted."
  aws cloudformation wait stack-delete-complete \
    --stack-name "${stack}" \
    --region "${REGION}" 2>/dev/null || true
  echo "  ✓ ${stack} deleted"
done

echo "Teardown complete. Remember to empty and delete retained S3 buckets manually."
