# Predictive Ad Creative Performance Scorer
### AWS Architecture Deep-Dive & Deployment Guide

---

## Architecture Overview

```
Client / Ad Platform
        │
        ▼
┌───────────────────┐
│  API Gateway      │  REST API (3 endpoints)
│  /v1/upload POST  │  → PresignedURL Lambda → S3 PUT URL
│  /v1/score  POST  │  → PipelineTrigger Lambda → Step Functions
│  /v1/score  GET   │  → Inference Lambda → DynamoDB read
└───────────────────┘
        │ POST /score triggers
        ▼
┌───────────────────────────────────────────────────────────┐
│  Step Functions Express Workflow                          │
│                                                           │
│  ValidateInput ──► ExtractFeatures ──► ModerationGate    │
│                        │                    │             │
│                (Rekognition CV)     [flagged?]            │
│                        │            ├─Yes─► FlaggedState  │
│                        │            └─No──► RunInference  │
│                                                 │         │
│                                         (SageMaker EP)   │
│                                                 │         │
│                                         PublishEvent      │
│                                         (EventBridge)     │
└───────────────────────────────────────────────────────────┘
        │                          │
        ▼                          ▼
┌──────────────┐         ┌──────────────────────┐
│  DynamoDB    │         │  SageMaker Endpoint   │
│  scores table│         │  XGBoost CTR Scorer   │
└──────────────┘         └──────────────────────┘
        │
        ▼
┌──────────────────────────────────┐
│  CloudWatch Dashboard + Alarms   │
│  SNS → Email Alerts              │
└──────────────────────────────────┘
```

---

## Template Dependency Order

| Order | Template File              | Stack Name Suffix   | Purpose                         |
|-------|---------------------------|---------------------|---------------------------------|
| 1     | 01-foundation.yaml        | -foundation         | S3, KMS, IAM Roles, SSM params  |
| 2     | 02-compute-and-storage.yaml | -compute          | DynamoDB, Lambda functions      |
| 3     | 03-api-gateway.yaml       | -api                | REST API + usage plan           |
| 4     | 04-step-functions.yaml    | -orchestration      | State Machine                   |
| 5     | 05-sagemaker.yaml         | -ml                 | Training job + endpoint         |
| 6     | 06-monitoring.yaml        | -monitoring         | Alarms + dashboard              |

---

## Quick Deploy

```bash
# Prerequisites
aws configure  # or use AWS_PROFILE / assumed role

# Deploy all stacks
chmod +x deploy.sh
./deploy.sh dev us-east-1 alerts@yourcompany.com
```

---

## Training Data Format

Upload CSVs to S3 BEFORE deploying Template 5.

### S3 paths
```
s3://ad-scorer-ml-artifacts-<account>-dev/
  training-data/
    train/          ← 80% of labelled creative data
      creative_features.csv
    validation/     ← 20% of labelled creative data
      creative_features.csv
```

### CSV Schema (no header row — XGBoost reads raw CSV)
```
<label>,<face_present>,<face_count>,<emotion_confidence>,<word_count>,<label_count>,<moderation_flag_count>,<color_saturation>
```

| Column Index | Feature Name           | Type  | Notes                             |
|-------------|------------------------|-------|-----------------------------------|
| 0           | label (CTR)            | float | 1 = clicked, 0 = not clicked. For regression: actual CTR float (0.0–1.0) |
| 1           | face_present           | int   | 0 or 1                            |
| 2           | face_count             | int   | Number of faces detected          |
| 3           | emotion_confidence     | float | Confidence of dominant emotion    |
| 4           | word_count             | int   | Words detected by Rekognition OCR |
| 5           | label_count            | int   | Number of Rekognition object labels |
| 6           | moderation_flag_count  | int   | Number of moderation labels       |
| 7           | color_saturation       | float | 0.0–1.0 (compute via PIL/Pillow)  |

### Example rows
```
1,1,2,94.5,8,14,0,0.72
0,0,0,0.0,24,6,0,0.41
1,1,1,87.2,3,18,0,0.85
0,0,0,0.0,0,2,1,0.30
```

---

## API Usage

### Step 1 — Get presigned upload URL
```bash
POST /v1/upload
Content-Type: application/json
x-api-key: <your-api-key>

{
  "content_type": "image/jpeg",
  "campaign_id": "summer-2026"
}

# Response
{
  "creative_id": "a1b2c3d4-...",
  "upload_url": "https://s3.amazonaws.com/...",
  "s3_key": "uploads/summer-2026/a1b2c3d4-...",
  "expires_in": 3600
}
```

### Step 2 — Upload the creative asset
```bash
curl -X PUT "<upload_url>" \
  -H "Content-Type: image/jpeg" \
  --upload-file ./ad_creative.jpg
```

### Step 3 — Submit for scoring
```bash
POST /v1/score
Content-Type: application/json
x-api-key: <your-api-key>

{
  "s3_bucket": "ad-scorer-creative-assets-<account>-dev",
  "s3_key": "uploads/summer-2026/a1b2c3d4-...",
  "creative_id": "a1b2c3d4-...",
  "campaign_id": "summer-2026"
}

# Response (HTTP 202 Accepted — async)
{
  "creative_id": "a1b2c3d4-...",
  "status": "PENDING",
  "execution_arn": "arn:aws:states:us-east-1:...:execution:...",
  "scored_at": "2026-05-11T10:30:00Z"
}
```

### Step 4 — Poll for result
```bash
GET /v1/score/a1b2c3d4-...
x-api-key: <your-api-key>

# Response when complete
{
  "creative_id": "a1b2c3d4-...",
  "ctr_score": 0.0842,
  "engagement_score": 0.0968,
  "status": "SCORED"
}
```

---

## Cost Estimates (dev environment, 1,000 scorings/day)

| Service         | Usage                       | Estimated Monthly Cost |
|----------------|------------------------------|------------------------|
| Rekognition     | 30,000 image API calls       | ~$3.00                |
| Lambda          | 90,000 invocations, 512MB    | ~$0.50                |
| SageMaker EP    | ml.t3.medium, 1 instance     | ~$65.00               |
| DynamoDB        | PAY_PER_REQUEST, 1K writes   | ~$1.00                |
| Step Functions  | 30,000 EXPRESS transitions   | ~$0.75                |
| API Gateway     | 30,000 API calls             | ~$0.10                |
| S3              | 50GB storage + requests      | ~$1.20                |
| **Total**       |                              | **~$72/month**        |

> 💡 Reduce SageMaker cost by using Serverless Inference (~$0.0001/inference) instead of a persistent endpoint when scoring volume is unpredictable.

---

## Post-Deployment Checklist

- [ ] Confirm SNS email subscription for alarms
- [ ] Upload training data CSVs to S3
- [ ] Deploy Template 05 (SageMaker) once training data is ready
- [ ] Wait for training job to complete (~20-40 min on ml.m5.xlarge)
- [ ] Update `ModelS3Key` parameter in Template 05 to point to trained model artifact
- [ ] Test the full pipeline with a sample image via the API
- [ ] Verify CloudWatch dashboard populates metrics
- [ ] Set up Rekognition feature Lambda layer with Pillow (for color saturation)

---

## Extending the Architecture

### Add video support
- Add `rekognition:StartLabelDetection` (async job) to Lambda role
- Add a "VideoProcessing" branch in Step Functions using a `.waitForTaskToken` pattern
- Store video analysis results in DynamoDB with TTL

### A/B model comparison
- Add a second SageMaker Production Variant with `InitialVariantWeight: 0.1` (10% traffic split)
- Compare `ctr_score` distributions between variants in CloudWatch

### Batch scoring
- Add an `EventBridge Scheduler` rule to trigger Step Functions Map state over all `PENDING` items in DynamoDB
- Use `SageMaker Batch Transform` instead of real-time endpoint for cost efficiency
